<?php 
//redireccionar a la vista de login

header('location: vistas/asistencia.php');  
 ?>